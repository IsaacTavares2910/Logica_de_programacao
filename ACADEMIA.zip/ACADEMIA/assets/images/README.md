# Pasta de imagens da Strong

Coloque aqui as imagens dos espaços da academia. Renomeie os arquivos para os seguintes nomes:

- `spring.jpg` — imagem da sala de spinning / spring
- `musculacao.jpg` — imagem da área de musculação
- `cardio.jpg` — imagem da zona de cardio

A página principal (`index.html`) já está configurada para usar esses nomes de arquivo.
