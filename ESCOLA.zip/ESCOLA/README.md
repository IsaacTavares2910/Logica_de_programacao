# 🚀 Escotech - Escola de Tecnologia do Futuro

Um website moderno, responsivo e elegante para a Escotech, uma instituição educacional voltada para formar profissionais de tecnologia. O site foi desenvolvido com HTML5 semântico, CSS3 avançado e JavaScript puro, seguindo as melhores práticas de desenvolvimento frontend.

---

## 📋 Estrutura de Arquivos

```
ESCOLA/
├── index.html      # Estrutura HTML semântica com todas as seções
├── style.css       # Estilização completa com variáveis CSS e responsividade
├── script.js       # Interações dinâmicas e validações
└── README.md       # Este arquivo
```

---

## 🎨 Paleta de Cores

- **Verde Neon (#00FF88)** - Destaques e efeitos de hover
- **Verde Escuro (#0B5F3F)** - Elementos estruturais
- **Verde Claro (#1ACD81)** - Botões principais
- **Fundo Primário (#0B0F19)** - Modo escuro premium
- **Fundo Secundário (#141820)** - Seções alternadas
- **Texto Primário (#FFFFFF)** - Texto principal
- **Texto Secundário (#B0B8C1)** - Textos informativos

---

## 📱 Responsividade

O site é totalmente responsivo e otimizado para:

- **Desktop** (1200px+) - Layout completo com múltiplas colunas
- **Tablet** (768px - 1199px) - Layout adaptado com 2 colunas
- **Mobile** (até 767px) - Layout single column com menu hambúrguer

---

## 🧱 Seções Principais

### 1. **Header / Navegação**
- Logo com ícone animado
- Menu de navegação com efeito hover suave
- Botão de CTA "Matricule-se"
- Menu hambúrguer para mobile
- Header fixo que muda de estilo ao rolar a página

### 2. **Hero Section**
- Título impactante com gradiente
- Subtítulo convincente
- Dois botões CTA (Comece Agora e Saiba Mais)
- Elementos visuais animados (esferas de gradiente)
- Snippet de código decorativo

### 3. **Sobre a Escola**
- Descrição institucional detalhada
- Estatísticas com animação de contagem
- Cards com números impressionantes (alunos, taxa de sucesso, etc.)

### 4. **Cursos Oferecidos**
- Cards modernos para cada curso
- Ícones representativos (emojis)
- Lista de habilidades por curso
- Efeito de elevação ao passar o mouse
- Botão "Conheça Mais" com feedback visual

### 5. **Diferenciais**
- 6 cards destacando pontos fortes
- Ícones e descrições claras
- Efeitos de hover com mudança de cor

### 6. **Planos e Preços**
- 3 planos comparativos (Start, Pro, Enterprise)
- Plano Pro destacado com selo "Mais Vendido"
- Lista de features com check/cross
- Preços formatados com separadores
- Diferentes tipos de botões por plano

### 7. **Depoimentos**
- Grid de 6 depoimentos de alunos
- Avaliações com estrelas
- Avatar placeholder com emojis
- Nome, cargo e depoimento
- Efeitos de hover elegantes

### 8. **Contato / Formulário**
- Formulário funcional com validação completa
- Campos: Nome, Email, Telefone, Curso, Mensagem
- Informações de contato (endereço, telefone, email)
- Links de redes sociais
- Modal de sucesso após envio

### 9. **Footer**
- Links para todas as seções
- Informações da empresa
- Copyright e créditos

---

## ⚡ Funcionalidades JavaScript

### Menu Móvel
- Menu hambúrguer responsivo
- Abre/fecha com animação suave
- Fecha ao clicar em um link ou fora do menu

### Header Fixo
- Muda de estilo quando você rola a página
- Background mais opaco e borda inferior ao scroll

### Smooth Scroll
- Rolagem suave entre seções
- Compensa a altura do header fixo automaticamente

### Validação de Formulário
- Valida nome (mínimo 3 caracteres)
- Valida email com regex
- Valida telefone (10-11 dígitos)
- Valida seleção de curso
- Exibe mensagens de erro estilizadas
- Mostra modal de sucesso após envio

### Animações
- Animação de entrada de elementos (fade-in)
- Contador de números nas estatísticas
- Esferas flutuantes no hero
- Transições suaves em botões e cards

### Atalhos de Teclado
- **Alt + C** - Foca no formulário de contato
- **Alt + H** - Volta ao topo da página
- **ESC** - Fecha o modal de sucesso

### Intersection Observer
- Anima elementos quando entram na viewport
- Contador de números começa ao entrar na seção de sobre

---

## 🎯 Como Usar

### 1. Abrir o Site
Simplesmente abra o arquivo `index.html` em seu navegador web preferido.

```bash
# No seu navegador, acesse:
file:///caminho/para/seu/ESCOLA/index.html
```

### 2. Personalizar as Cores
Edite as variáveis CSS no início do arquivo `style.css`:

```css
:root {
    --color-green-neon: #00FF88;
    --color-green-dark: #0B5F3F;
    /* ... outras cores ... */
}
```

### 3. Modificar Conteúdo
Edite o `index.html` para:
- Mudar textos
- Adicionar/remover seções
- Atualizar informações de contato

### 4. Integrar com Backend
Para enviar realmente os dados do formulário, modifique a seção de envio no `script.js`:

```javascript
// Linha ~238 em script.js
if (formularioValido) {
    // Adicione código para enviar para seu servidor
    // Exemplo com fetch:
    fetch('/api/contato', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ nome, email, telefone, curso, mensagem })
    })
    .then(response => response.json())
    .then(data => exibirModalSucesso())
    .catch(error => console.error('Erro:', error));
}
```

---

## 🚀 Deploy

### GitHub Pages
```bash
# 1. Crie um repositório no GitHub chamado "escotech"
# 2. Faça upload dos arquivos
# 3. Vá em Settings > Pages > Source > Deploy from a branch
# 4. Seu site estará em: https://seu-usuario.github.io/escotech
```

### Vercel (Recomendado)
```bash
# 1. Crie uma conta em vercel.com
# 2. Conecte seu repositório GitHub
# 3. Vercel detectará automaticamente e fará deploy
```

### Netlify
```bash
# 1. Crie uma conta em netlify.com
# 2. Arraste a pasta "ESCOLA" para fazer upload
# 3. Seu site estará online em segundos
```

---

## 📊 Performance

- **Carregamento Rápido**: Sem dependências externas, apenas CSS nativo
- **Otimizado para Mobile**: Design mobile-first
- **Acessibilidade**: HTML semântico e bom contraste de cores
- **SEO-Friendly**: Meta tags, estrutura semântica, títulos apropriados

---

## 🔧 Recursos Técnicos

### CSS
- Variáveis CSS para fácil customização
- Flexbox e CSS Grid para layouts responsivos
- Transições e animações suaves
- Gradientes lineares e radiais
- Media queries para responsividade

### JavaScript
- Vanilla JS (sem frameworks)
- Manipulação eficiente do DOM
- Intersection Observer para animações
- Event listeners bem organizados
- Validação de formulário robusta

### HTML
- Semântica HTML5 apropriada
- Atributos aria para acessibilidade
- Meta tags completas
- Fontes do Google importadas

---

## 🎓 Seções de Cursos

O site apresenta 4 cursos principais:

1. **Desenvolvimento Full-Stack**
   - React & Next.js
   - Node.js & Express
   - Bancos de Dados
   - Deploy em Produção

2. **Data Science & IA**
   - Python & Pandas
   - Machine Learning
   - Deep Learning
   - Análise de Dados

3. **Cyber Security**
   - Segurança de Rede
   - Pentest & Hacking Ético
   - Criptografia
   - Compliance & Governança

4. **UX/UI Design**
   - Design Thinking
   - Prototipagem
   - Figma & Adobe XD
   - User Research

---

## 💰 Planos de Preços

### Start - R$ 299/mês
- 3 cursos básicos
- Comunidade de alunos
- Materiais em vídeo HD
- Certificado digital

### Pro - R$ 799/mês (Mais Vendido)
- Todos os 8 cursos
- Mentorias individuais
- Projetos práticos com feedback
- Suporte prioritário 24/7
- Certificados profissionais
- Acesso a eventos exclusivos

### Enterprise - Customizado
- Treinamento customizado
- Turmas dedicadas
- Relatórios de desempenho
- Consultor dedicado
- Certificação corporativa
- SLA garantido

---

## 📞 Informações de Contato (Placeholders)

- **Telefone**: (11) 3000-1000
- **Email**: contato@escotech.com
- **Endereço**: São Paulo, SP - Brasil

Atualize estas informações com os dados reais da sua instituição.

---

## 🎉 Depoimentos

O site inclui 6 depoimentos animados de alunos fictícios. Você pode:
- Substituir nomes e profissões
- Atualizar os emojis com imagens reais
- Adicionar novos depoimentos

---

## ⚙️ Customizações Recomendadas

1. **Logo**: Substitua o ícone "⚡" e texto "Escotech" pelo seu próprio logo
2. **Cores**: Ajuste a paleta no CSS para match sua marca
3. **Fontes**: Mude as famílias de fontes no CSS
4. **Conteúdo**: Personalize todos os textos e informações
5. **Backend**: Integre com seu servidor para processar formulários

---

## 🐛 Troubleshooting

### Elementos não aparecem?
- Verifique se todos os 3 arquivos (HTML, CSS, JS) estão na mesma pasta
- Limpe o cache do navegador (Ctrl+Shift+Delete)
- Tente em outro navegador

### Menu não funciona no mobile?
- Verifique a largura da janela (< 768px)
- Abra o console (F12) e procure por erros

### Formulário não valida?
- Verifique se o arquivo script.js está sendo carregado
- Abra o console (F12) para ver mensagens de erro

### Animações lentas?
- Desabilite a aceleração de hardware em seu navegador
- Tente em um dispositivo diferente
- Verifique a saúde do sistema

---

## 📚 Recursos Úteis

- [MDN Web Docs](https://developer.mozilla.org/) - Referência completa de HTML/CSS/JS
- [CSS Tricks](https://css-tricks.com/) - Dicas e truques de CSS
- [JavaScript.info](https://javascript.info/) - Tutorial interativo de JavaScript
- [Figma](https://www.figma.com/) - Design de interfaces
- [Google Fonts](https://fonts.google.com/) - Fontes livres para web

---

## 📄 Licença

Este projeto é de código aberto e pode ser usado livremente para fins educacionais e comerciais.

---

## 🙌 Contribuições

Se encontrar bugs ou tiver sugestões de melhorias, entre em contato ou faça um pull request!

---

## ✨ Criado com 💚 para o Futuro da Tecnologia

**Escotech - Formando os Profissionais do Amanhã**

Desenvolvido com foco em qualidade, performance e experiência do usuário.

---

**Última atualização**: 2024  
**Versão**: 1.0  
**Status**: Production Ready ✅
