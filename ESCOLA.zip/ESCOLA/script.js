/* ============================================
   CONFIGURAÇÕES E INICIALIZAÇÃO
   ============================================ */

// Elementos do DOM
const menuToggle = document.getElementById('menuToggle');
const navMenu = document.getElementById('navMenu');
const header = document.querySelector('.header');
const navLinks = document.querySelectorAll('.nav-link');
const contatoForm = document.getElementById('contatoForm');
const modalSucesso = document.getElementById('modalSucesso');
const closeModal = document.getElementById('closeModal');
const closeModalBtn = document.getElementById('closeModalBtn');

// Estado da aplicação
let isMenuOpen = false;

/* ============================================
   MENU HAMBÚRGUER (MOBILE)
   ============================================ */

/**
 * Abre ou fecha o menu móvel
 */
function toggleMenu() {
    isMenuOpen = !isMenuOpen;
    menuToggle.classList.toggle('active', isMenuOpen);
    navMenu.classList.toggle('active', isMenuOpen);
}

/**
 * Fecha o menu quando um link é clicado
 */
function closeMenuOnLinkClick() {
    isMenuOpen = false;
    menuToggle.classList.remove('active');
    navMenu.classList.remove('active');
}

// Event Listeners para menu
menuToggle.addEventListener('click', toggleMenu);

navLinks.forEach(link => {
    link.addEventListener('click', closeMenuOnLinkClick);
});

// Fechar menu ao clicar fora
document.addEventListener('click', (e) => {
    if (!e.target.closest('.navbar') && isMenuOpen) {
        closeMenuOnLinkClick();
    }
});

/* ============================================
   HEADER FIXO COM SCROLL
   ============================================ */

/**
 * Altera o estilo do header quando a página é rolada
 */
let lastScrollPosition = 0;

function updateHeaderOnScroll() {
    const currentScrollPosition = window.scrollY;

    if (currentScrollPosition > 80) {
        header.classList.add('scrolled');
    } else {
        header.classList.remove('scrolled');
    }

    lastScrollPosition = currentScrollPosition;
}

window.addEventListener('scroll', updateHeaderOnScroll);

/* ============================================
   SMOOTH SCROLL PARA ÂNCORAS
   ============================================ */

/**
 * Implementa scroll suave para links de navegação
 */
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        // Ignora se o link for vazio
        if (this.getAttribute('href') === '#') {
            return;
        }

        e.preventDefault();

        const targetId = this.getAttribute('href').substring(1);
        const targetElement = document.getElementById(targetId);

        if (targetElement) {
            // Calcula o offset para compensar o header fixo
            const headerHeight = header.offsetHeight;
            const targetPosition = targetElement.offsetTop - headerHeight;

            window.scrollTo({
                top: targetPosition,
                behavior: 'smooth'
            });
        }
    });
});

/* ============================================
   BOTÕES CTA (CALL TO ACTION)
   ============================================ */

/**
 * Rola até a seção de contato ao clicar em botões CTA
 */
const ctaBotoes = [
    document.getElementById('ctaPrincipal'),
    document.getElementById('btnPrincipal'),
    document.getElementById('btnSecundario')
];

ctaBotoes.forEach(botao => {
    if (botao) {
        botao.addEventListener('click', () => {
            const contatoSection = document.getElementById('contato');
            if (contatoSection) {
                const headerHeight = header.offsetHeight;
                const targetPosition = contatoSection.offsetTop - headerHeight;

                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });

                // Foca no primeiro campo do formulário
                setTimeout(() => {
                    document.getElementById('nome').focus();
                }, 500);
            }
        });
    }
});

/* ============================================
   VALIDAÇÃO E ENVIO DO FORMULÁRIO
   ============================================ */

/**
 * Valida um endereço de email
 */
function validarEmail(email) {
    const regexEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regexEmail.test(email);
}

/**
 * Valida um número de telefone
 */
function validarTelefone(telefone) {
    // Remove caracteres não numéricos
    const telefoneLimpo = telefone.replace(/\D/g, '');
    // Verifica se tem entre 10 e 11 dígitos
    return telefoneLimpo.length >= 10 && telefoneLimpo.length <= 11;
}

/**
 * Exibe uma mensagem de erro na validação
 */
function mostrarErro(campo, mensagem) {
    let errorElement = campo.nextElementSibling;

    // Remove erro anterior se existir
    if (errorElement && errorElement.classList.contains('error-message')) {
        errorElement.remove();
    }

    // Cria elemento de erro
    const divErro = document.createElement('div');
    divErro.className = 'error-message';
    divErro.textContent = mensagem;
    divErro.style.cssText = `
        color: #ff6b6b;
        font-size: 12px;
        margin-top: 4px;
    `;

    campo.parentNode.appendChild(divErro);
    campo.style.borderColor = '#ff6b6b';

    // Remove erro após 3 segundos
    setTimeout(() => {
        divErro.remove();
        campo.style.borderColor = 'var(--color-border)';
    }, 3000);
}

/**
 * Manipula o envio do formulário
 */
contatoForm.addEventListener('submit', (e) => {
    e.preventDefault();

    // Obtém os valores dos campos
    const nome = document.getElementById('nome').value.trim();
    const email = document.getElementById('email').value.trim();
    const telefone = document.getElementById('telefone').value.trim();
    const curso = document.getElementById('curso').value;
    const mensagem = document.getElementById('mensagem').value.trim();

    // Flags de validação
    let formularioValido = true;

    // Valida Nome
    if (nome.length < 3) {
        mostrarErro(document.getElementById('nome'), 'Nome deve ter pelo menos 3 caracteres');
        formularioValido = false;
    }

    // Valida Email
    if (!validarEmail(email)) {
        mostrarErro(document.getElementById('email'), 'Digite um email válido');
        formularioValido = false;
    }

    // Valida Telefone (se preenchido)
    if (telefone && !validarTelefone(telefone)) {
        mostrarErro(document.getElementById('telefone'), 'Telefone inválido. Use um número válido');
        formularioValido = false;
    }

    // Valida Curso
    if (!curso) {
        mostrarErro(document.getElementById('curso'), 'Selecione um curso de interesse');
        formularioValido = false;
    }

    // Se o formulário for válido
    if (formularioValido) {
        // Aqui você pode adicionar código para enviar os dados para um servidor
        // Por enquanto, simulamos o envio
        console.log({
            nome,
            email,
            telefone,
            curso,
            mensagem,
            dataEnvio: new Date().toLocaleString('pt-BR')
        });

        // Reseta o formulário
        contatoForm.reset();

        // Mostra modal de sucesso
        exibirModalSucesso();
    }
});

/* ============================================
   MODAL DE SUCESSO
   ============================================ */

/**
 * Exibe o modal de sucesso
 */
function exibirModalSucesso() {
    modalSucesso.classList.add('show');

    // Auto-fechar após 5 segundos
    setTimeout(() => {
        fecharModal();
    }, 5000);
}

/**
 * Fecha o modal de sucesso
 */
function fecharModal() {
    modalSucesso.classList.remove('show');
}

// Event Listeners para fechar o modal
closeModal.addEventListener('click', fecharModal);
closeModalBtn.addEventListener('click', fecharModal);

// Fecha o modal ao clicar no fundo (overlay)
modalSucesso.addEventListener('click', (e) => {
    if (e.target === modalSucesso) {
        fecharModal();
    }
});

// Fecha o modal ao pressionar ESC
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && modalSucesso.classList.contains('show')) {
        fecharModal();
    }
});

/* ============================================
   INTERAÇÕES COM CARDS
   ============================================ */

/**
 * Adiciona animação de clique nos botões de cursos
 */
const botoesCursos = document.querySelectorAll('.curso-card .btn-outline');

botoesCursos.forEach(botao => {
    botao.addEventListener('click', () => {
        // Feedback visual simples
        botao.style.transform = 'scale(0.95)';
        setTimeout(() => {
            botao.style.transform = 'scale(1)';
        }, 100);

        // Mostra notificação
        exibirNotificacao('Conteúdo em breve! Entre em contato conosco.');
    });
});

/* ============================================
   NOTIFICAÇÃO SIMPLES
   ============================================ */

/**
 * Exibe uma notificação flutuante
 */
function exibirNotificacao(mensagem) {
    const notificacao = document.createElement('div');
    notificacao.style.cssText = `
        position: fixed;
        top: 100px;
        right: 20px;
        background-color: rgba(0, 255, 136, 0.2);
        border: 1px solid var(--color-green-light);
        color: var(--color-green-neon);
        padding: 16px 20px;
        border-radius: 8px;
        font-size: 14px;
        z-index: 1500;
        max-width: 300px;
        animation: slideInRight 0.3s ease-out;
    `;
    notificacao.textContent = mensagem;

    document.body.appendChild(notificacao);

    // Remove a notificação após 3 segundos
    setTimeout(() => {
        notificacao.style.animation = 'slideOutRight 0.3s ease-out';
        setTimeout(() => {
            notificacao.remove();
        }, 300);
    }, 3000);
}

/* ============================================
   ANIMAÇÕES DE CARREGAMENTO
   ============================================ */

/**
 * Anima elementos quando entram na viewport
 */
function iniciarIntersectionObserver() {
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, {
        threshold: 0.1
    });

    // Observa todos os cards e itens que devem animar
    document.querySelectorAll(
        '.curso-card, .diferencial-item, .depoimento-card, .preco-card, .stat-card'
    ).forEach(elemento => {
        elemento.style.opacity = '0';
        elemento.style.transform = 'translateY(20px)';
        elemento.style.transition = 'opacity 0.5s ease-out, transform 0.5s ease-out';
        observer.observe(elemento);
    });
}

// Inicializa o observer quando a página carrega
window.addEventListener('load', iniciarIntersectionObserver);

/* ============================================
   CONTAGEM DE NÚMEROS (ANIMAÇÃO)
   ============================================ */

/**
 * Anima a contagem de números nas estatísticas
 */
function animarNumeros() {
    const statsCards = document.querySelectorAll('.stat-number');
    let contadoresJaExecutados = false;

    const observerStats = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting && !contadoresJaExecutados) {
                contadoresJaExecutados = true;

                statsCards.forEach(card => {
                    const numeroFinal = parseInt(card.textContent.replace(/\D/g, ''));
                    let numeroAtual = 0;

                    const incremento = numeroFinal / 30;
                    const intervalo = setInterval(() => {
                        numeroAtual += incremento;

                        if (numeroAtual >= numeroFinal) {
                            numeroAtual = numeroFinal;
                            clearInterval(intervalo);
                        }

                        if (numeroFinal > 100) {
                            card.textContent = Math.floor(numeroAtual).toLocaleString('pt-BR');
                        } else {
                            card.textContent = Math.floor(numeroAtual);
                        }

                        // Adiciona o símbolo final se houver
                        if (numeroFinal === numeroAtual && card.textContent.includes('K')) {
                            card.textContent = Math.floor(numeroAtual).toLocaleString('pt-BR') + 'K+';
                        } else if (numeroFinal === numeroAtual && card.textContent.includes('%')) {
                            card.textContent = Math.floor(numeroAtual) + '%';
                        }
                    }, 30);
                });

                observerStats.unobserve(entry.target);
            }
        });
    }, {
        threshold: 0.5
    });

    const statsContainer = document.querySelector('.sobre-stats');
    if (statsContainer) {
        observerStats.observe(statsContainer);
    }
}

window.addEventListener('load', animarNumeros);

/* ============================================
   KEYBOARD SHORTCUTS
   ============================================ */

/**
 * Implementa atalhos de teclado úteis
 */
document.addEventListener('keydown', (e) => {
    // Alt + C para abrir formulário de contato
    if (e.altKey && e.key === 'c') {
        e.preventDefault();
        document.getElementById('nome').focus();
    }

    // Alt + H para voltar ao topo
    if (e.altKey && e.key === 'h') {
        e.preventDefault();
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }
});

/* ============================================
   PERFORMANCE E OTIMIZAÇÕES
   ============================================ */

/**
 * Monitora o desempenho e exibe avisos de carregamento
 */
window.addEventListener('load', () => {
    // Marca o tempo de carregamento
    const performanceData = window.performance.timing;
    const pageLoadTime = performanceData.loadEventEnd - performanceData.navigationStart;

    console.log(`⚡ Página carregada em ${pageLoadTime}ms`);
    console.log('✅ Escotech está pronta para impressionar seus alunos!');
});

/* ============================================
   INICIALIZAÇÃO FINAL
   ============================================ */

/**
 * Função de inicialização da aplicação
 */
function inicializarAplicacao() {
    // Verifica se os elementos essenciais existem
    if (!contatoForm || !modalSucesso) {
        console.warn('⚠️ Alguns elementos não foram encontrados no DOM');
    }

    // Log de inicialização
    console.log('🚀 Escotech - Aplicação inicializada com sucesso!');
}

// Inicializa quando o DOM estiver pronto
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', inicializarAplicacao);
} else {
    inicializarAplicacao();
}
