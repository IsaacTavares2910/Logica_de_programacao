# 📱 Portfólio Pessoal Completo - HTML5, CSS3 e JavaScript

Um site de portfólio moderno, responsivo e funcional desenvolvido com **HTML5**, **CSS3** e **JavaScript vanilla**, incluindo um painel administrativo para gerenciar conteúdo dinamicamente usando `localStorage`.

## 🎯 Características Principais

### Front-end do Portfólio
- ✅ **Single Page Application (SPA)** com navegação suave
- ✅ **Design Dark Theme** elegante e moderno (Preto + Azul Navy)
- ✅ **100% Responsivo** (Mobile, Tablet, Desktop)
- ✅ **Seções Dinâmicas**: Hero, Sobre, Habilidades, Projetos, Contato
- ✅ **Menu Hambúrguer** para mobile
- ✅ **Formulário de Contato** funcional

### Painel Administrativo
- ✅ **Editar "Sobre Mim"** em tempo real
- ✅ **Gerenciar Projetos** (Adicionar, Editar, Deletar)
- ✅ **Upload de Imagens** via URL ou Base64
- ✅ **Layout Admin** com Sidebar e Conteúdo principal
- ✅ **Persistência com localStorage** (sem banco de dados!)

## 📁 Estrutura de Pastas

```
Portfolio/
├── index.html              # Página principal do portfólio
├── style.css              # Estilos do portfólio
├── script.js              # JavaScript do portfólio
├── admin/
│   ├── admin.html         # Página do painel admin
│   ├── admin.css          # Estilos do admin
│   └── admin.js           # JavaScript do admin
└── assets/
    └── images/            # Pasta para armazenar imagens localmente
```

## 🚀 Como Usar

### 1. Acessar o Portfólio
Abra o arquivo `index.html` em um navegador web moderno. O site carregará com os dados padrão armazenados no `localStorage`.

### 2. Acessar o Painel Admin
Clique no botão **"Admin"** no canto superior direito do portfólio, ou abra diretamente o arquivo `admin/admin.html`.

### 3. Editar "Sobre Mim"
No painel admin:
1. Clique em **"Sobre Mim"** no menu lateral
2. Edite o texto no textarea
3. Clique em **"Salvar Alterações"**
4. Os dados serão salvos no localStorage e apareçam no portfólio

### 4. Gerenciar Projetos
No painel admin:
1. Clique em **"Gerenciar Projetos"** no menu lateral
2. Preencha o formulário com os detalhes do projeto:
   - **Título**: Nome do projeto
   - **Descrição**: Breve descrição
   - **Imagem**: URL da imagem OU arquivo local
   - **Links**: GitHub e/ou Live/Deploy
3. Clique em **"Adicionar Projeto"**
4. Os projetos aparecerão na seção de Projetos do portfólio

### 5. Upload de Imagens

#### Via URL (Recomendado)
Cole a URL completa da imagem hospedada em um serviço como:
- Imgur: https://imgur.com
- Cloudinary: https://cloudinary.com
- GitHub: Via repositório público

#### Via Base64 (Arquivo Local)
1. Clique em "Ou Upload de Arquivo"
2. Selecione uma imagem do seu computador (JPG, PNG, GIF, WebP)
3. O arquivo será convertido automaticamente para Base64
4. A imagem será armazenada diretamente no localStorage

## 💾 Como Funciona o localStorage

O projeto usa o **localStorage** do navegador como "banco de dados":

```javascript
// Admin.js ESCREVE no localStorage
localStorage.setItem('portfolioData', JSON.stringify(data));

// Script.js LÊ do localStorage
const data = JSON.parse(localStorage.getItem('portfolioData'));
```

**Fluxo:**
1. Você edita dados no `admin.html`
2. `admin.js` salva os dados no localStorage
3. Quando você acessa `index.html`, `script.js` lê os dados salvos
4. O portfólio exibe os dados atualizados

**Vantagens:**
- ✅ Sem necessidade de servidor/banco de dados
- ✅ Dados persistem entre sessões
- ✅ Funciona totalmente offline
- ✅ Sincronização automática entre abas

## 🎨 Personalização

### Mudar Cores
Abra `style.css` e procure pelas variáveis de cor no `:root`:

```css
:root {
    --bg-dark: #0a0e27;          /* Fundo escuro principal */
    --accent-blue: #3b82f6;       /* Azul de destaque */
    --text-light: #e8eef5;        /* Texto claro */
    /* ... mais cores ... */
}
```

### Adicionar Seções
1. Adicione a nova seção no HTML
2. Crie os estilos no CSS
3. Ajuste `script.js` para carregar dados se necessário

### Adicionar Funcionalidades
`admin.js` e `script.js` são bem comentados. Você pode estender as funcionalidades facilmente!

## 📋 Personalizações Necessárias

Antes de publicar, atualize:

1. **Nome e profissão** - Edite diretamente no Hero ou via Admin
2. **Links de redes sociais** - `index.html`, seção de Contato
3. **Link GitHub** - Não se esqueça de atualizar o link pessoal
4. **Email/WhatsApp** - Para o formulário de contato (atualmente não envia, apenas valida)
5. **Foto de perfil** - Coloque uma imagem na pasta `assets/images/` e referencie no CSS

## 🌐 Publicar Online

### Opção 1: GitHub Pages (Gratuito)
1. Crie um repositório no GitHub
2. Envie todos os arquivos
3. Vá em Settings > Pages > Branch: main
4. Seu site estará em: `https://seuusuario.github.io/repository-name`

### Opção 2: Netlify (Gratuito e Recomendado)
1. Acesse https://netlify.com
2. Conecte seu repositório GitHub
3. Deploy automático a cada `push`

### Opção 3: Vercel (Gratuito)
1. Acesse https://vercel.com
2. Importe seu repositório
3. Deploy em segundos

## ⚠️ Limitações do localStorage

- **Limite de espaço**: ~5-10MB por domínio
- **Armazenamento local**: Dados não sincronizam entre dispositivos
- **Segurança**: Dados visíveis para qualquer JavaScript na página
- **Imagens Base64**: Consomem mais espaço (recomenda-se usar URLs)

## 🔒 Melhorias Futuras (Sem Frameworks)

Se quiser expandir o projeto no futuro:
- [ ] Implementar autenticação simples
- [ ] Exportar/Importar dados como JSON
- [ ] Adicionar modo escuro/claro (já tem dark theme)
- [ ] Integrar com API de email real
- [ ] Adicionar analytics

## 🛠️ Tecnologias Utilizadas

- **HTML5**: Semântico e acessível
- **CSS3**: Grid, Flexbox, Gradientes, Animações
- **JavaScript Vanilla**: Sem frameworks, puro e rápido
- **localStorage**: Persistência de dados no navegador

## 📱 Compatibilidade

Testado em:
- ✅ Chrome/Chromium (v90+)
- ✅ Firefox (v88+)
- ✅ Safari (v14+)
- ✅ Edge (v90+)
- ✅ Mobile browsers (iOS Safari, Chrome Mobile)

## 📝 Licença

Este projeto é de código aberto e livre para uso pessoal e comercial.

## 🤝 Suporte

Se encontrar problemas:
1. Abra o DevTools (F12)
2. Verifique o Console para erros
3. Limpe o localStorage se necessário: `localStorage.clear()`

---

**Desenvolvido com ❤️ usando HTML5, CSS3 e JavaScript Vanilla**
