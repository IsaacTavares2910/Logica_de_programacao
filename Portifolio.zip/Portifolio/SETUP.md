# 🚀 GUIA DE INÍCIO RÁPIDO - PORTFÓLIO

## ⚡ Primeiros Passos

### 1️⃣ Abrir o Portfólio
Abra o arquivo **`index.html`** em qualquer navegador moderno. Você verá:
- Hero section com seu nome
- Seções de Sobre, Habilidades e Projetos
- Formulário de contato
- Links para redes sociais

### 2️⃣ Abrir o Painel Admin
**Opção A**: Clique no botão "Admin" no topo direito do portfólio

**Opção B**: Abra direto `admin/admin.html` no navegador

## 📝 Primeiro Uso - Passo a Passo

### PASSO 1: Editar "Sobre Mim"
1. Abra o admin
2. Clique em "📝 Sobre Mim" no menu lateral esquerdo
3. Edite o texto no campo de texto
4. Clique em "Salvar Alterações"
5. Volte ao portfólio - o texto será atualizado automaticamente!

### PASSO 2: Adicionar Seu Primeiro Projeto
1. No admin, clique em "🎯 Gerenciar Projetos"
2. Preencha os campos:
   - **Título**: Ex: "Meu Projeto Incrível"
   - **Descrição**: Ex: "Um app para gerenciar tarefas"
   - **Imagem**: Cole uma URL de imagem (ex: https://via.placeholder.com/300x200)
   - **GitHub**: Seu link GitHub (opcional)
   - **Live**: Seu link do projeto (opcional)
3. Clique em "Adicionar Projeto"
4. O projeto aparecerá na seção "Projetos" do portfólio

### PASSO 3: Testar Funcionamento
1. Abra duas abas do navegador
2. Uma com o portfólio (index.html)
3. Outra com o admin (admin.html)
4. Edite algo no admin
5. Volte para o portfólio (mesmo sem recarregar)
6. Veja a mudança acontecer em tempo real!

## 🖼️ Upload de Imagens - 3 Formas

### Opção 1️⃣: URL da Internet (Mais Fácil ⭐)
```
Cole a URL completa da imagem:
https://via.placeholder.com/300x200
https://i.imgur.com/sua-imagem.jpg
https://images.unsplash.com/...
```

### Opção 2️⃣: Upload de Arquivo (Convertido para Base64)
```
1. No admin, clique em "Ou Upload de Arquivo"
2. Selecione uma imagem do seu PC
3. Pronto! Será convertida automaticamente
```

### Opção 3️⃣: Imagens Locais (Git + GitHub)
```
1. Coloque as imagens em: assets/images/
2. Faça upload para o GitHub
3. Use a URL bruta no admin:
   https://raw.githubusercontent.com/seu-user/seu-repo/main/assets/images/foto.jpg
```

## 🎨 Personalizar Cores e Estilos

### Mudar Cores Principais
Abra `style.css` e encontre:
```css
:root {
    --bg-dark: #0a0e27;          /* Fundo escuro */
    --accent-blue: #3b82f6;       /* Azul principal */
    --text-light: #e8eef5;        /* Texto claro */
    --text-gray: #a0aec0;         /* Texto secundário */
    --accent-cyan: #06b6d4;       /* Destaque cyan */
}
```

Mude os valores HEX para outras cores!

### Mudar Logo/Nome
Em `index.html`, procure por:
```html
<div class="logo">
    <a href="#inicio">Portfolio</a>  <!-- Mude "Portfolio" -->
</div>
```

## 📱 Testar Responsividade

1. Abra o portfólio no navegador
2. Pressione **F12** para abrir DevTools
3. Clique no ícone de dispositivo/responsividade
4. Teste em:
   - iPhone (375px)
   - iPad (768px)
   - Desktop (1920px)

## 🔍 Verificar Dados Salvos

No navegador, pressione **F12** e vá para **Console**:

```javascript
// Ver dados salvos
JSON.parse(localStorage.getItem('portfolioData'))

// Limpar tudo (cuidado!)
localStorage.clear()

// Recarregar página
location.reload()
```

## 🌐 Publicar Online

### Via GitHub Pages (Gratuito)
1. Crie uma conta em github.com
2. Crie um repositório público chamado `portfolio`
3. Envie todos os arquivos
4. Settings > Pages > Selecione branch `main`
5. Seu site estará em: `https://seu-usuario.github.io/portfolio`

### Via Netlify (Recomendado)
1. Acesse netlify.com
2. Clique em "Deploy to Netlify" ou "New site from Git"
3. Conecte seu repositório GitHub
4. Deploy automático! 🎉

### Via Vercel (Alternativa)
1. Acesse vercel.com
2. Import seu repositório
3. Pronto em segundos!

## ⚙️ Troubleshooting

### Problema: Dados desaparecem ao recarregar
**Solução**: localStorage pode ser limitado. Limpe o cache:
- DevTools > Application > Clear all

### Problema: Imagens não aparecem
**Solução**: Verifique a URL:
- Colar diretamente no navegador
- Certifique-se que começa com `https://`

### Problema: Mudanças no admin não aparecem no portfólio
**Solução**: 
- Recarregue a página (F5)
- Limpe o cache (Ctrl+Shift+Delete)
- Verifique se localStorage está ativado

### Problema: "Cannot read properties of null"
**Solução**: localStorage vazio. Recarregue a página.

## 📚 Estrutura de Arquivos Explicada

```
Portfolio/
├── index.html          ← Abra aqui primeiro (portfólio)
├── style.css           ← Estilos do portfólio
├── script.js           ← Lê dados do localStorage
├── README.md           ← Documentação completa
├── SETUP.md            ← Este arquivo
│
├── admin/
│   ├── admin.html      ← Abra aqui para editar (admin)
│   ├── admin.css       ← Estilos do admin
│   └── admin.js        ← Escreve dados no localStorage
│
└── assets/
    └── images/         ← Coloque imagens aqui
        └── README-IMAGES.html
```

## 🎯 Checklist Antes de Publicar

- [ ] Editei "Sobre Mim" com minha história
- [ ] Adicionei minhas habilidades técnicas
- [ ] Adicionei pelo menos 3 projetos
- [ ] Atualizei links do GitHub e LinkedIn
- [ ] Testei em mobile, tablet e desktop
- [ ] Testei o formulário de contato
- [ ] Publicei online (GitHub Pages, Netlify, etc)

## 💡 Dicas Pro

1. **Backup dos dados**: Exporte regularmente via console
2. **Múltiplas abas**: Sincroniza automaticamente
3. **Imagens em Base64**: Ótimas para protótipos, não para produção
4. **URLs de imagens**: Sempre use HTTPS
5. **SEO**: Atualize títulos e meta tags em `index.html`

## 🎓 Próximos Passos (Aprender)

Quer expandir este projeto?
1. Adicionar autenticação
2. Integrar com backend Node.js
3. Usar um framework como React
4. Implementar blog dinâmico
5. Adicionar sistema de comentários

---

**Pronto para começar? Abra `index.html` agora! 🚀**

Dúvidas? Veja `README.md` para documentação completa.
