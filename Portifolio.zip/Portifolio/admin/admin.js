/**
 * ============================================
 * SCRIPT DO PAINEL ADMINISTRATIVO
 * Gerencia dados salvos no localStorage
 * 
 * COMO FUNCIONA O localStorage:
 * 1. admin.js escreve dados em localStorage
 * 2. script.js (portfólio) lê esses dados
 * 3. Quando você edita no admin, os dados
 *    são salvos e o portfólio reflete as mudanças
 * ============================================
 */

// ============================================
// VARIÁVEIS GLOBAIS
// ============================================
let portfolioData = {};
let editingProjectId = null;

// ============================================
// INICIALIZAÇÃO
// ============================================
document.addEventListener('DOMContentLoaded', function() {
    loadPortfolioData();
    setupMenuNavigation();
    setupProfileForm();
    setupAboutForm();
    setupProjectsForm();
    loadProjectsList();
    setupModal();
    loadProfileImage();
});

// ============================================
// CARREGAR DADOS DO localStorage
// ============================================
function loadPortfolioData() {
    try {
        const data = localStorage.getItem('portfolioData');
        
        if (data) {
            portfolioData = JSON.parse(data);
            console.log('Dados carregados do localStorage:', portfolioData);
        } else {
            // Se não houver dados, criar estrutura padrão
            portfolioData = {
                aboutText: 'Sou um desenvolvedor apaixonado por tecnologia...',
                projects: []
            };
            savePortfolioData();
        }
        
        // Preencher formulário de "Sobre"
        const aboutTextarea = document.getElementById('aboutTextarea');
        if (aboutTextarea && portfolioData.aboutText) {
            aboutTextarea.value = portfolioData.aboutText;
        }
    } catch (error) {
        console.error('Erro ao carregar dados:', error);
        showMessage('aboutMessage', 'Erro ao carregar dados', 'error');
    }
}

// ============================================
// SALVAR DADOS NO localStorage
// ============================================
function savePortfolioData() {
    try {
        localStorage.setItem('portfolioData', JSON.stringify(portfolioData));
        console.log('Dados salvos no localStorage');
        return true;
    } catch (error) {
        console.error('Erro ao salvar dados:', error);
        return false;
    }
}

// ============================================
// NAVEGAÇÃO DO MENU
// ============================================
function setupMenuNavigation() {
    const menuItems = document.querySelectorAll('.menu-item');
    
    menuItems.forEach(item => {
        item.addEventListener('click', function() {
            const section = this.getAttribute('data-section');
            
            // Remover classe active de todos os items
            menuItems.forEach(m => m.classList.remove('active'));
            
            // Adicionar classe active ao item clicado
            this.classList.add('active');
            
            // Mostrar seção correspondente
            showSection(section);
        });
    });
}

// ============================================
// MOSTRAR/OCULTAR SEÇÕES
// ============================================
function showSection(sectionId) {
    // Ocultar todas as seções
    const sections = document.querySelectorAll('.admin-section');
    sections.forEach(section => section.classList.remove('active'));
    
    // Mostrar seção selecionada
    const activeSection = document.getElementById(sectionId);
    if (activeSection) {
        activeSection.classList.add('active');
    }
}

// ============================================
// FORMULÁRIO "SOBRE MIM"
// ============================================
function setupAboutForm() {
    const form = document.getElementById('aboutForm');
    
    if (!form) return;
    
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const aboutText = document.getElementById('aboutTextarea').value.trim();
        
        if (!aboutText) {
            showMessage('aboutMessage', 'Por favor, escreva algo sobre você!', 'warning');
            return;
        }
        
        // Salvar dados
        portfolioData.aboutText = aboutText;
        
        if (savePortfolioData()) {
            showMessage('aboutMessage', '✓ Alterações salvas com sucesso!', 'success');
            // Sincronizar com portfólio (se estiver aberto em outra aba)
            notifyPortfolioUpdate();
        } else {
            showMessage('aboutMessage', '✗ Erro ao salvar as alterações', 'error');
        }
    });
}

// ============================================
// FORMULÁRIO DE NOVO PROJETO
// ============================================
function setupProjectsForm() {
    const form = document.getElementById('projectForm');
    
    if (!form) return;
    
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const title = document.getElementById('projectTitle').value.trim();
        const description = document.getElementById('projectDescription').value.trim();
        const imageUrl = document.getElementById('projectImage').value.trim();
        const imageFile = document.getElementById('projectImageFile').files[0];
        const github = document.getElementById('projectGithub').value.trim();
        const live = document.getElementById('projectLive').value.trim();
        
        // Validações
        if (!title || !description) {
            showMessage('projectMessage', 'Título e Descrição são obrigatórios!', 'warning');
            return;
        }
        
        if (!imageUrl && !imageFile) {
            showMessage('projectMessage', 'Selecione uma imagem (URL ou arquivo)!', 'warning');
            return;
        }
        
        // Se houver arquivo, converter para Base64
        if (imageFile) {
            convertFileToBase64(imageFile, function(base64) {
                addProject(title, description, base64, github, live);
            });
        } else {
            addProject(title, description, imageUrl, github, live);
        }
    });
}

// ============================================
// CONVERTER ARQUIVO PARA BASE64
// ============================================
function convertFileToBase64(file, callback) {
    const reader = new FileReader();
    
    reader.onload = function(e) {
        callback(e.target.result);
    };
    
    reader.onerror = function() {
        showMessage('projectMessage', 'Erro ao processar a imagem', 'error');
    };
    
    // Validar tamanho da imagem (máx 2MB)
    if (file.size > 2 * 1024 * 1024) {
        showMessage('projectMessage', 'A imagem não pode exceder 2MB', 'error');
        return;
    }
    
    reader.readAsDataURL(file);
}

// ============================================
// ADICIONAR PROJETO
// ============================================
function addProject(title, description, image, github, live) {
    try {
        // Criar ID único
        const id = Date.now();
        
        // Criar objeto do projeto
        const newProject = {
            id: id,
            title: title,
            description: description,
            image: image,
            github: github || '',
            live: live || ''
        };
        
        // Adicionar ao array de projetos
        if (!portfolioData.projects) {
            portfolioData.projects = [];
        }
        
        portfolioData.projects.push(newProject);
        
        // Salvar no localStorage
        if (savePortfolioData()) {
            showMessage('projectMessage', '✓ Projeto adicionado com sucesso!', 'success');
            
            // Limpar formulário
            document.getElementById('projectForm').reset();
            
            // Recarregar lista
            loadProjectsList();
            
            // Sincronizar com portfólio
            notifyPortfolioUpdate();
        } else {
            showMessage('projectMessage', '✗ Erro ao adicionar projeto', 'error');
        }
    } catch (error) {
        console.error('Erro ao adicionar projeto:', error);
        showMessage('projectMessage', '✗ Erro ao adicionar projeto', 'error');
    }
}

// ============================================
// CARREGAR LISTA DE PROJETOS
// ============================================
function loadProjectsList() {
    const projectsList = document.getElementById('projectsList');
    
    if (!projectsList) return;
    
    // Limpar lista
    projectsList.innerHTML = '';
    
    // Verificar se há projetos
    if (!portfolioData.projects || portfolioData.projects.length === 0) {
        projectsList.innerHTML = '<div class="project-item-empty">Nenhum projeto adicionado ainda. Adicione um novo projeto acima!</div>';
        return;
    }
    
    // Renderizar cada projeto
    portfolioData.projects.forEach(project => {
        const projectItem = document.createElement('div');
        projectItem.className = 'project-item';
        projectItem.innerHTML = `
            <div class="project-item-info">
                <h4>${escapeHtml(project.title)}</h4>
                <p>${escapeHtml(project.description)}</p>
                <div class="project-item-links">
                    ${project.github ? `<a href="${project.github}" target="_blank">GitHub</a> | ` : ''}
                    ${project.live ? `<a href="${project.live}" target="_blank">Live</a>` : ''}
                </div>
            </div>
            <div class="project-item-actions">
                <button class="btn btn-edit" onclick="openEditModal(${project.id})">Editar</button>
                <button class="btn btn-danger" onclick="deleteProject(${project.id})">Deletar</button>
            </div>
        `;
        
        projectsList.appendChild(projectItem);
    });
}

// ============================================
// ABRIR MODAL DE EDIÇÃO
// ============================================
function openEditModal(projectId) {
    const project = portfolioData.projects.find(p => p.id === projectId);
    
    if (!project) return;
    
    editingProjectId = projectId;
    
    // Preencher formulário
    document.getElementById('editProjectId').value = project.id;
    document.getElementById('editProjectTitle').value = project.title;
    document.getElementById('editProjectDescription').value = project.description;
    document.getElementById('editProjectImage').value = project.image;
    document.getElementById('editProjectGithub').value = project.github || '';
    document.getElementById('editProjectLive').value = project.live || '';
    
    // Mostrar modal
    const modal = document.getElementById('editProjectModal');
    modal.classList.add('show');
}

// ============================================
// FECHAR MODAL
// ============================================
function closeEditModal() {
    const modal = document.getElementById('editProjectModal');
    modal.classList.remove('show');
    editingProjectId = null;
}

// ============================================
// SETUP DO MODAL
// ============================================
function setupModal() {
    const modal = document.getElementById('editProjectModal');
    const closeBtn = modal.querySelector('.close-modal');
    const cancelBtn = document.getElementById('cancelEdit');
    const form = document.getElementById('editProjectForm');
    
    // Fechar ao clicar no X
    closeBtn.addEventListener('click', closeEditModal);
    
    // Fechar ao clicar em Cancelar
    cancelBtn.addEventListener('click', closeEditModal);
    
    // Fechar ao clicar fora do modal
    modal.addEventListener('click', function(e) {
        if (e.target === modal) {
            closeEditModal();
        }
    });
    
    // Salvar edições
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        saveProjectEdits();
    });
}

// ============================================
// SALVAR EDIÇÕES DO PROJETO
// ============================================
function saveProjectEdits() {
    const id = parseInt(document.getElementById('editProjectId').value);
    const title = document.getElementById('editProjectTitle').value.trim();
    const description = document.getElementById('editProjectDescription').value.trim();
    const image = document.getElementById('editProjectImage').value.trim();
    const github = document.getElementById('editProjectGithub').value.trim();
    const live = document.getElementById('editProjectLive').value.trim();
    
    // Validar
    if (!title || !description || !image) {
        alert('Preencha todos os campos obrigatórios!');
        return;
    }
    
    // Encontrar e atualizar projeto
    const projectIndex = portfolioData.projects.findIndex(p => p.id === id);
    
    if (projectIndex !== -1) {
        portfolioData.projects[projectIndex] = {
            id: id,
            title: title,
            description: description,
            image: image,
            github: github,
            live: live
        };
        
        if (savePortfolioData()) {
            closeEditModal();
            loadProjectsList();
            notifyPortfolioUpdate();
            alert('✓ Projeto atualizado com sucesso!');
        } else {
            alert('✗ Erro ao atualizar projeto');
        }
    }
}

// ============================================
// DELETAR PROJETO
// ============================================
function deleteProject(projectId) {
    if (!confirm('Tem certeza que deseja deletar este projeto?')) {
        return;
    }
    
    // Remover projeto
    portfolioData.projects = portfolioData.projects.filter(p => p.id !== projectId);
    
    if (savePortfolioData()) {
        loadProjectsList();
        notifyPortfolioUpdate();
        showMessage('projectMessage', '✓ Projeto deletado com sucesso!', 'success');
    } else {
        showMessage('projectMessage', '✗ Erro ao deletar projeto', 'error');
    }
}

// ============================================
// MOSTRAR MENSAGENS DE STATUS
// ============================================
function showMessage(elementId, message, type) {
    const element = document.getElementById(elementId);
    
    if (!element) return;
    
    element.textContent = message;
    element.className = `message show ${type}`;
    
    // Auto-remover após 5 segundos
    setTimeout(() => {
        element.classList.remove('show');
    }, 5000);
}

// ============================================
// NOTIFICAR PORTFÓLIO DE ATUALIZAÇÃO
// ============================================
function notifyPortfolioUpdate() {
    // Disparar evento customizado
    const event = new Event('portfolioDataUpdated');
    window.dispatchEvent(event);
    
    console.log('Portfólio notificado para sincronizar dados');
}

// ============================================
// ESCAPE HTML (SEGURANÇA)
// ============================================
function escapeHtml(text) {
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, m => map[m]);
}

// ============================================
// GERENCIAR FOTO DE PERFIL
// ============================================
function setupProfileForm() {
    const form = document.getElementById('profileForm');
    const fileInput = document.getElementById('profileImageFile');
    const removeBtn = document.getElementById('removeProfileBtn');
    
    if (!form) return;
    
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const file = fileInput.files[0];
        
        if (!file) {
            showMessage('profileMessage', 'Selecione uma imagem!', 'warning');
            return;
        }
        
        // Validar tamanho (máx 5MB)
        if (file.size > 5 * 1024 * 1024) {
            showMessage('profileMessage', 'Imagem não pode exceder 5MB', 'error');
            return;
        }
        
        // Converter para Base64
        convertFileToBase64(file, function(base64) {
            portfolioData.profileImage = base64;
            
            if (savePortfolioData()) {
                showMessage('profileMessage', '✓ Foto de perfil salva com sucesso!', 'success');
                loadProfileImage();
                fileInput.value = '';
                notifyPortfolioUpdate();
            } else {
                showMessage('profileMessage', '✗ Erro ao salvar foto', 'error');
            }
        });
    });
    
    // Remover foto
    removeBtn.addEventListener('click', function() {
        if (!portfolioData.profileImage) {
            showMessage('profileMessage', 'Nenhuma foto para remover', 'warning');
            return;
        }
        
        if (confirm('Tem certeza que deseja remover a foto de perfil?')) {
            delete portfolioData.profileImage;
            savePortfolioData();
            loadProfileImage();
            showMessage('profileMessage', '✓ Foto removida com sucesso!', 'success');
            notifyPortfolioUpdate();
        }
    });
}

function loadProfileImage() {
    const preview = document.getElementById('profileImagePreview');
    const status = document.getElementById('profileImageStatus');
    
    if (portfolioData.profileImage) {
        preview.src = portfolioData.profileImage;
        status.textContent = '✓ Foto salva';
        status.style.color = '#10b981';
    } else {
        preview.src = 'https://via.placeholder.com/200';
        status.textContent = 'Nenhuma foto salva';
        status.style.color = '#a0aec0';
    }
}

console.log('Admin.js carregado - Painel administrativo ativo');
