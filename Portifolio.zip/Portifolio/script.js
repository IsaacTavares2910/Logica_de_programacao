/**
 * ============================================
 * SCRIPT PRINCIPAL - PORTFÓLIO
 * Gerencia localStorage, carregamento de dados
 * e interações do usuário
 * ============================================
 * 
 * O localStorage funciona assim:
 * - admin.js escreve dados em localStorage
 * - script.js (este arquivo) lê esses dados
 * - Quando a página carrega, os dados salvos
 *   no admin aparecem automaticamente no site
 */

// ============================================
// INICIALIZAÇÃO
// ============================================
document.addEventListener('DOMContentLoaded', function() {
    initializePortfolio();
    setupMenuHamburger();
    loadAboutText();
    loadProfileImage();
    loadProjects();
    setupContactForm();
    setupNavigation();
});

// ============================================
// FUNÇÃO PRINCIPAL DE INICIALIZAÇÃO
// ============================================
function initializePortfolio() {
    console.log('Portfólio inicializado');
    
    // Verificar se existem dados no localStorage
    // Se não existirem, usar dados padrão
    if (!localStorage.getItem('portfolioData')) {
        initializeDefaultData();
    }
}

// ============================================
// DADOS PADRÃO DO PORTFÓLIO
// ============================================
function initializeDefaultData() {
    const defaultData = {
        aboutText: `Sou um desenvolvedor apaixonado por tecnologia com uma bagagem única: 
        experiência em vendas e relacionamento com clientes. Essa combinação me permite 
        criar soluções que não apenas funcionam, mas que também agregam valor real às pessoas.

        Minha trajetória começou no mundo das vendas, onde aprendi sobre comunicação, 
        negociação e entendimento das necessidades do cliente. Esses conhecimentos foram 
        fundamentais para que eu transitasse para a programação, trazendo uma perspectiva 
        diferente: sempre penser no usuário final.

        Hoje, trabalho como desenvolvedor full stack, criando soluções web modernas e eficientes. 
        Sou especializado em HTML5, CSS3, JavaScript e tenho experiência com várias tecnologias 
        e ferramentas de desenvolvimento.`,
        
        projects: [
            {
                id: 1,
                title: 'Projeto 1: Landing Page Responsiva',
                description: 'Uma landing page moderna desenvolvida com HTML5, CSS3 e JavaScript, com design responsivo.',
                image: 'https://via.placeholder.com/300x200?text=Landing+Page',
                github: 'https://github.com/seuusername/projeto1',
                live: 'https://seusite.com/projeto1'
            },
            {
                id: 2,
                title: 'Projeto 2: Aplicativo de Tarefas',
                description: 'Um gerenciador de tarefas com persistência de dados utilizando localStorage.',
                image: 'https://via.placeholder.com/300x200?text=Todo+App',
                github: 'https://github.com/seuusername/projeto2',
                live: 'https://seusite.com/projeto2'
            },
            {
                id: 3,
                title: 'Projeto 3: Dashboard de Dados',
                description: 'Dashboard interativo com gráficos e estatísticas em tempo real.',
                image: 'https://via.placeholder.com/300x200?text=Dashboard',
                github: 'https://github.com/seuusername/projeto3',
                live: 'https://seusite.com/projeto3'
            }
        ]
    };
    
    localStorage.setItem('portfolioData', JSON.stringify(defaultData));
    console.log('Dados padrão do portfólio criados no localStorage');
}

// ============================================
// CARREGAR TEXTO "SOBRE MIM"
// ============================================
function loadAboutText() {
    try {
        const data = JSON.parse(localStorage.getItem('portfolioData'));
        const aboutElement = document.getElementById('aboutText');
        
        if (data && data.aboutText && aboutElement) {
            // Dividir o texto em parágrafos e renderizar
            const paragraphs = data.aboutText.split('\n').filter(p => p.trim() !== '');
            aboutElement.innerHTML = paragraphs
                .map(p => `<p>${p.trim()}</p>`)
                .join('');
        }
    } catch (error) {
        console.error('Erro ao carregar texto sobre:', error);
    }
}

// ============================================
// CARREGAR PROJETOS
// ============================================
function loadProjects() {
    try {
        const data = JSON.parse(localStorage.getItem('portfolioData'));
        const projectsGrid = document.getElementById('projectsGrid');
        
        if (!projectsGrid) return;
        
        // Limpar projetos existentes (mantém apenas o template)
        projectsGrid.innerHTML = '';
        
        if (data && data.projects && Array.isArray(data.projects)) {
            // Renderizar cada projeto
            data.projects.forEach(project => {
                const projectCard = createProjectCard(project);
                projectsGrid.appendChild(projectCard);
            });
            
            console.log(`${data.projects.length} projetos carregados`);
        } else {
            projectsGrid.innerHTML = '<p style="grid-column: 1 / -1; text-align: center; color: var(--text-gray);">Nenhum projeto adicionado ainda. Acesse o painel admin para adicionar.</p>';
        }
    } catch (error) {
        console.error('Erro ao carregar projetos:', error);
    }
}

// ============================================
// CRIAR ELEMENTO DO PROJETO
// ============================================
function createProjectCard(project) {
    const article = document.createElement('article');
    article.className = 'project-card';
    article.innerHTML = `
        <div class="project-image">
            <img src="${project.image || 'https://via.placeholder.com/300x200?text=Sem+Imagem'}" 
                 alt="${project.title}" 
                 onerror="this.src='https://via.placeholder.com/300x200?text=Erro+Imagem'">
        </div>
        <div class="project-content">
            <h3>${project.title}</h3>
            <p>${project.description}</p>
            <div class="project-links">
                ${project.github ? `<a href="${project.github}" target="_blank" class="link-github">GitHub</a>` : ''}
                ${project.live ? `<a href="${project.live}" target="_blank" class="link-live">Ver Live</a>` : ''}
            </div>
        </div>
    `;
    return article;
}

// ============================================
// CONFIGURAR FORMULÁRIO DE CONTATO
// ============================================
function setupContactForm() {
    const form = document.getElementById('contactForm');
    
    if (!form) return;
    
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const name = document.getElementById('name').value;
        const email = document.getElementById('email').value;
        const message = document.getElementById('message').value;
        
        // Validação simples
        if (!name.trim() || !email.trim() || !message.trim()) {
            alert('Por favor, preencha todos os campos!');
            return;
        }
        
        // Validação de email simples
        if (!isValidEmail(email)) {
            alert('Por favor, insira um email válido!');
            return;
        }
        
        // Aqui você poderia enviar o email para um servidor
        // Por enquanto, vamos apenas armazenar no localStorage e exibir mensagem de sucesso
        console.log('Mensagem para contato:', {name, email, message});
        
        alert(`Obrigado pela mensagem, ${name}! Entraremos em contato em breve.`);
        
        // Limpar formulário
        form.reset();
    });
}

// ============================================
// VALIDAÇÃO DE EMAIL
// ============================================
function isValidEmail(email) {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
}

// ============================================
// MENU HAMBÚRGUER - MOBILE
// ============================================
function setupMenuHamburger() {
    const hamburger = document.querySelector('.hamburger');
    const navLinks = document.querySelector('.nav-links');
    
    if (!hamburger || !navLinks) return;
    
    hamburger.addEventListener('click', function() {
        navLinks.classList.toggle('active');
    });
    
    // Fechar menu ao clicar em um link
    document.querySelectorAll('.nav-links a').forEach(link => {
        link.addEventListener('click', function() {
            navLinks.classList.remove('active');
        });
    });
}

// ============================================
// NAVEGAÇÃO SUAVE E ATIVO
// ============================================
function setupNavigation() {
    const navLinks = document.querySelectorAll('.nav-links a:not(.admin-link)');
    
    window.addEventListener('scroll', function() {
        updateActiveNavLink();
    });
    
    // Adicionar smooth scroll aos links
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            const href = this.getAttribute('href');
            if (href.startsWith('#')) {
                e.preventDefault();
                const targetId = href.substring(1);
                const targetElement = document.getElementById(targetId);
                
                if (targetElement) {
                    targetElement.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            }
        });
    });
}

// ============================================
// ATUALIZAR LINK ATIVO NA NAVEGAÇÃO
// ============================================
function updateActiveNavLink() {
    const sections = document.querySelectorAll('section[id]');
    const navLinks = document.querySelectorAll('.nav-links a:not(.admin-link)');
    
    let current = '';
    
    sections.forEach(section => {
        const sectionTop = section.offsetTop;
        const sectionHeight = section.clientHeight;
        
        if (window.pageYOffset >= sectionTop - 100) {
            current = section.getAttribute('id');
        }
    });
    
    navLinks.forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('href') === `#${current}`) {
            link.classList.add('active');
        }
    });
}

// ============================================
// FUNCÇÕES AUXILIARES - localStorage
// ============================================

/**
 * Salvar dados no localStorage
 * Usado principalmente pelo admin.js
 */
function savePortfolioData(data) {
    try {
        localStorage.setItem('portfolioData', JSON.stringify(data));
        console.log('Dados salvos com sucesso no localStorage');
        return true;
    } catch (error) {
        console.error('Erro ao salvar dados:', error);
        return false;
    }
}

/**
 * Obter dados do localStorage
 * Retorna os dados salvos ou null
 */
function getPortfolioData() {
    try {
        const data = localStorage.getItem('portfolioData');
        return data ? JSON.parse(data) : null;
    } catch (error) {
        console.error('Erro ao obter dados:', error);
        return null;
    }
}

/**
 * Sincronizar portfólio (usado quando admin.js salva dados)
 * Recarrega os dados do localStorage no portfólio
 */
function syncPortfolioFromAdmin() {
    loadAboutText();
    loadProjects();
    console.log('Portfólio sincronizado com admin');
}

// ============================================
// EVENT LISTENER PARA ARMAZENAMENTO
// ============================================
// Quando dados são alterados em outro aba/janela do navegador
window.addEventListener('storage', function(e) {
    if (e.key === 'portfolioData') {
        console.log('Dados foram alterados no admin. Sincronizando...');
        syncPortfolioFromAdmin();
    }
});

console.log('Script.js carregado - Sistema de localStorage ativo');
