# Portfólio Pessoal

Um portfólio pessoal moderno e responsivo desenvolvido com HTML, CSS e JavaScript puro.

## Estrutura do Projeto

```
portfolio/
├── index.html          # Arquivo principal HTML
├── css/
│   └── style.css       # Estilos CSS
├── js/
│   └── script.js       # JavaScript para interatividade
└── img/                # Pasta para imagens
```

## Funcionalidades

- **Design Responsivo**: Funciona perfeitamente em desktop, tablet e mobile
- **Navegação Suave**: Menu com smooth scroll entre seções
- **Menu Mobile**: Menu hambúrguer animado para dispositivos móveis
- **Seções Completas**:
  - Hero Section com apresentação
  - Sobre Mim com texto e placeholder para foto
  - Projetos com cards interativos
  - Habilidades com barras de progresso
  - Contato com formulário funcional
  - Rodapé com links sociais

## Esquema de Cores

- Azul escuro: #1A237E
- Preto: #000000
- Azul claro: #42A5F5
- Branco: #FFFFFF

## Como Personalizar

1. **Conteúdo**: Substitua os placeholders `[Seu Nome]`, `[Descrição do Projeto 1]`, etc. pelo seu conteúdo real.

2. **Links**: Atualize os links dos projetos, redes sociais e email no arquivo `index.html`.

3. **Imagens**: Adicione suas imagens na pasta `img/` e atualize os caminhos no HTML.

4. **Habilidades**: Ajuste as porcentagens das barras de habilidades no CSS (`.skill-progress`).

5. **Cores**: Modifique as variáveis de cor no arquivo `style.css` se desejar um esquema diferente.

## Como Executar

Abra o arquivo `index.html` diretamente no navegador ou use um servidor local:

```bash
# Com Python (se instalado)
python -m http.server 8000

# Ou simplesmente abra index.html no navegador
```

## Tecnologias Utilizadas

- HTML5
- CSS3 (Flexbox, Grid, Media Queries)
- JavaScript (ES6+)
- Google Fonts (Roboto)

## Funcionalidades JavaScript

- Menu hambúrguer responsivo
- Smooth scroll para navegação
- Validação de formulário de contato
- Animação das barras de habilidades
- Header dinâmico ao rolar

## Responsividade

O site é totalmente responsivo com breakpoints em:
- 768px (tablet)
- 480px (mobile)

## Próximos Passos

- Adicionar animações CSS mais avançadas
- Implementar um backend para o formulário de contato
- Adicionar mais interatividade (modais, filtros, etc.)
- Otimizar performance e SEO