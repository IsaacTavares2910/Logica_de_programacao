const mobileToggle = document.getElementById('mobileToggle');
const navMenu = document.getElementById('navMenu');
const planButtons = document.querySelectorAll('.btn-plan');
const inputAmount = document.getElementById('inputAmount');
const calculateBtn = document.getElementById('calculateBtn');
const cdiValue = document.getElementById('cdiValue');
const savingsValue = document.getElementById('savingsValue');
const prevReview = document.getElementById('prevReview');
const nextReview = document.getElementById('nextReview');
const reviewCards = document.querySelectorAll('.review-card');
let activeReview = 0;

// Gráfico de performance
function initPerformanceChart() {
  const ctx = document.getElementById('performanceChart');
  if (!ctx) return;

  new Chart(ctx, {
    type: 'line',
    data: {
      labels: ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'],
      datasets: [
        {
          label: 'FinTrack',
          data: [100, 105, 112, 119, 127, 136, 146, 157, 169, 182, 196, 211],
          borderColor: '#20f0b9',
          backgroundColor: 'rgba(32, 240, 185, 0.1)',
          borderWidth: 2.5,
          fill: true,
          tension: 0.4,
          pointRadius: 4,
          pointBackgroundColor: '#20f0b9',
          pointBorderColor: 'rgba(32, 240, 185, 0.3)',
          pointBorderWidth: 2,
        },
        {
          label: 'Mercado padrão',
          data: [100, 102, 106, 109, 113, 118, 122, 127, 132, 138, 143, 149],
          borderColor: '#3f8cff',
          backgroundColor: 'rgba(63, 140, 255, 0.05)',
          borderWidth: 2.5,
          fill: true,
          tension: 0.4,
          pointRadius: 4,
          pointBackgroundColor: '#3f8cff',
          pointBorderColor: 'rgba(63, 140, 255, 0.3)',
          pointBorderWidth: 2,
        },
      ],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      interaction: {
        intersect: false,
        mode: 'index',
      },
      plugins: {
        legend: {
          display: true,
          labels: {
            color: '#e8eef8',
            font: { size: 12, family: "'Inter', sans-serif" },
            padding: 15,
            usePointStyle: true,
            pointStyle: 'circle',
          },
        },
        filler: {
          propagate: true,
        },
      },
      scales: {
        y: {
          beginAtZero: false,
          grid: {
            color: 'rgba(255, 255, 255, 0.05)',
            drawBorder: false,
          },
          ticks: {
            color: '#8aa3c1',
            font: { size: 11 },
            callback: function (value) {
              return value + '';
            },
          },
        },
        x: {
          grid: {
            display: false,
          },
          ticks: {
            color: '#8aa3c1',
            font: { size: 11 },
          },
        },
      },
    },
  });
}

function toggleMenu() {
  navMenu.classList.toggle('active');
  mobileToggle.classList.toggle('open');
}

mobileToggle.addEventListener('click', toggleMenu);

planButtons.forEach((button) => {
  button.addEventListener('click', () => {
    const planName = button.dataset.plan;
    alert(`Plano selecionado: ${planName}. Vamos direcionar você para o checkout!`);
  });
});

calculateBtn.addEventListener('click', () => {
  const amount = Number(inputAmount.value);
  if (!amount || amount <= 0) {
    alert('Digite um valor válido para simular o rendimento.');
    return;
  }

  const cdiRate = 0.0125; // 1.25% mensal estimado
  const savingsRate = 0.0045; // 0.45% mensal estimado

  const cdiResult = amount * (1 + cdiRate);
  const savingsResult = amount * (1 + savingsRate);

  cdiValue.textContent = cdiResult.toLocaleString('pt-BR', {
    style: 'currency',
    currency: 'BRL',
  });
  savingsValue.textContent = savingsResult.toLocaleString('pt-BR', {
    style: 'currency',
    currency: 'BRL',
  });
});

function showReview(index) {
  reviewCards.forEach((card, position) => {
    card.classList.toggle('hidden', position !== index);
  });
}

function moveReview(direction) {
  activeReview += direction;
  if (activeReview < 0) activeReview = reviewCards.length - 1;
  if (activeReview >= reviewCards.length) activeReview = 0;
  showReview(activeReview);
}

prevReview.addEventListener('click', () => moveReview(-1));
nextReview.addEventListener('click', () => moveReview(1));

showReview(activeReview);

// Inicializar gráfico quando a página carregar
document.addEventListener('DOMContentLoaded', initPerformanceChart);

// Se a página já está carregada (ex: refresh)
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initPerformanceChart);
} else {
  initPerformanceChart();
}
